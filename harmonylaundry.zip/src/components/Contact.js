import React from 'react'

function Contact() {
  return (
    <section className='max-w-screen-lg mx-auto py-10 mb-5 flex flex-col gap-y-4 px-4 my-20 lg:my-0 xl:px-0'>
        <div className='flex flex-col items-center'>
            <h3 className='text-blue-600 uppercase font-bold'>Kontak</h3>
            <h4 className='text-blue-900 font-bold md:text-4xl text-2xl'>Hubungi Kami</h4>
        </div>
        <div className='grid md:grid-cols-4 grid-cols-1 gap-x-8 gap-y-4'>
            <div className=''>
                <div className='grid md:grid-cols-2 gap-4'>
                    

                </div>
            </div>
        
        </div>

    </section>
  )
}

export default Contact